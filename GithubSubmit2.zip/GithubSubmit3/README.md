# GithubSubmit BFAA DICODING
This is Submission 1 for BFAA Dicoding

in this submission we have to present github user data provided by dicoding
we have to present it in two ways on main page and detail page

# Main page
  main page is where user data first presented,in my submission i make every user 
  show on list using recycler view and i make my own profile on the top of the list.
  every user card is clickable including mine it will redirect to the user detail page
  
# Detail page
  this page will show you the detail for user you pick. the information is provided by dicoding
  they give as string resource file for this task
